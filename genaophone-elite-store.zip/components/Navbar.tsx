import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Navbar: React.FC = () => {
  const location = useLocation();

  const navLinkClass = (path: string) => `uppercase text-[11px] font-bold tracking-[0.2em] transition-colors ${
    location.pathname === path ? 'text-primary' : 'text-gray-400 hover:text-white'
  }`;

  return (
    <>
      <div className="bg-surface py-2.5 px-4 text-[10px] uppercase tracking-[0.2em] border-b border-border text-gray-500 hidden md:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center font-bold">
          <div className="flex gap-8">
            <span className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[14px] text-primary">local_shipping</span> Envío Priority bonificado
            </span>
            <span className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[14px] text-primary">verified</span> Garantía Oficial Genao
            </span>
          </div>
          <div className="flex gap-8 items-center">
            <a href="#" className="hover:text-white transition-colors">Soporte</a>
            <a href="#" className="hover:text-white transition-colors">Rastreo</a>
          </div>
        </div>
      </div>

      <header className="sticky top-0 z-50 bg-background/90 backdrop-blur-xl border-b border-border">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-12">
            <Link to="/" className="text-2xl font-bold flex items-center gap-2 group">
              <div className="w-10 h-10 bg-primary flex items-center justify-center rounded-sm group-hover:bg-white transition-colors">
                <span className="material-symbols-outlined text-black text-2xl font-bold">phone_iphone</span>
              </div>
              <span className="tracking-tighter font-display uppercase italic text-xl">Genao<span className="text-primary not-italic">Phone</span></span>
            </Link>
            
            <nav className="hidden lg:flex gap-10">
              <Link to="/" className={navLinkClass('/')}>Inicio</Link>
              <Link to="/category" className={navLinkClass('/category')}>Celulares</Link>
              <Link to="/category" className={navLinkClass('/tvs')}>Televisores</Link>
              <Link to="/category" className={navLinkClass('/consolas')}>Consolas</Link>
              <Link to="/category" className={navLinkClass('/outlet') + ' text-primary/80'}>Outlet</Link>
            </nav>
          </div>

          <div className="flex items-center gap-6">
            <div className="relative hidden md:block group">
              <input 
                type="text" 
                placeholder="BUSCAR TECNOLOGÍA ELITE..." 
                className="pl-2 pr-10 py-2 bg-transparent border-b border-border focus:border-primary placeholder-white/20 text-xs font-bold uppercase tracking-wider w-64 focus:ring-0 outline-none transition-all"
              />
              <span className="material-symbols-outlined absolute right-0 top-1/2 -translate-y-1/2 text-gray-600 group-hover:text-primary transition-colors cursor-pointer">search</span>
            </div>
            
            <button className="text-gray-400 hover:text-primary transition-colors">
              <span className="material-symbols-outlined font-light">favorite</span>
            </button>
            
            <button className="text-gray-400 hover:text-primary transition-colors relative">
              <span className="material-symbols-outlined font-light text-[26px]">shopping_bag</span>
              <span className="absolute -top-1 -right-1 bg-primary text-black text-[9px] w-4 h-4 rounded-sm flex items-center justify-center font-black">03</span>
            </button>
            
            <button className="bg-primary text-white text-[10px] font-black uppercase px-6 py-2.5 rounded-sm hover:bg-white hover:text-black transition-all hidden sm:block">
              Acceso
            </button>
          </div>
        </div>
      </header>
    </>
  );
};

export default Navbar;