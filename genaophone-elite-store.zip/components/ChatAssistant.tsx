import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";

interface Message {
  role: 'user' | 'model';
  text: string;
}

const SYSTEM_INSTRUCTION = `
Eres "GenaoBot", el Asistente de Ventas y Soporte de GenaoPhone, una tienda elite de electrónicos.
Tu objetivo es aumentar ventas, resolver dudas técnicas y guiar al usuario a WhatsApp para cerrar la compra.

TONO:
- Profesional, sofisticado, pero cálido (Estilo "Concierge").
- Respuestas concisas. Usa viñetas.

CONOCIMIENTO CLAVE (iPhone 15 Pro vs iPhone 16):
- Si preguntan diferencias, destaca:
  1. Pantalla: iPhone 15 Pro tiene 120Hz (ProMotion) vs 60Hz del iPhone 16.
  2. Construcción: 15 Pro es Titanio (más premium/ligero) vs 16 es Aluminio.
  3. Cámaras: 15 Pro tiene Teleobjetivo 3x dedicado. 16 tiene el nuevo botón de control de cámara.
  4. Chip: A17 Pro (15 Pro) vs A18 (16). Ambos vuelan, pero el 15 Pro se siente más "Pro" por la pantalla.
- Recomendación: "Si valoras la fluidez de pantalla y fotografía zoom, ve por el 15 Pro. Si quieres el último procesador y colores vibrantes, el 16."

REGLAS DE NEGOCIO:
- NO inventes precios. Si no lo sabes, di que consulten disponibilidad real.
- PAGOS/STOCK: Para cerrar compras, verificar stock exacto o pagos, SIEMPRE manda a WhatsApp.
- LINK WHATSAPP: Usa siempre este formato: "Escríbenos para finalizar tu pedido: https://wa.me/18295555555"

Formato de respuesta: Texto plano, usa saltos de línea para separar ideas.
`;

const ChatAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Bienvenido a GenaoPhone Elite. ¿Buscas algún dispositivo en particular o quieres comparar modelos?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [chatSession, setChatSession] = useState<any>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  // Initialize Chat Session
  useEffect(() => {
    const initChat = async () => {
        try {
            // NOTE: In a real production app, ensure process.env.API_KEY is available.
            // If running locally without env, this might fail unless configured.
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' }); 
            const chat = ai.chats.create({
                model: 'gemini-3-flash-preview',
                config: {
                    systemInstruction: SYSTEM_INSTRUCTION,
                }
            });
            setChatSession(chat);
        } catch (error) {
            console.error("Error initializing AI:", error);
        }
    };
    initChat();
  }, []);

  const handleSend = async () => {
    if (!input.trim() || !chatSession) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const result = await chatSession.sendMessage({ message: userMsg });
      const responseText = result.text;
      
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      console.error("Error sending message:", error);
      setMessages(prev => [...prev, { role: 'model', text: "Lo siento, tuve un error de conexión. Por favor contáctanos directamente por WhatsApp." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Chat Window */}
      {isOpen && (
        <div className="mb-4 w-[350px] md:w-[400px] h-[500px] bg-surface border border-border shadow-[0_0_50px_rgba(0,0,0,0.8)] flex flex-col animate-fade-in-up rounded-sm overflow-hidden">
          {/* Header */}
          <div className="bg-surface-highlight border-b border-border p-4 flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary flex items-center justify-center rounded-sm">
                 <span className="material-symbols-outlined text-black text-sm font-bold">smart_toy</span>
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-white">Genao Assistant</h3>
                <span className="flex items-center gap-1 text-[9px] text-green-500 font-bold uppercase tracking-widest">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span> Online
                </span>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-gray-500 hover:text-white transition-colors"
            >
              <span className="material-symbols-outlined">close</span>
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide bg-background/50">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div 
                  className={`max-w-[85%] p-3 text-xs leading-relaxed font-medium ${
                    msg.role === 'user' 
                      ? 'bg-primary text-white rounded-t-lg rounded-bl-lg' 
                      : 'bg-surface-highlight border border-border text-gray-300 rounded-t-lg rounded-br-lg'
                  }`}
                >
                  {/* Basic parsing for links */}
                  {msg.text.split(/(https?:\/\/[^\s]+)/g).map((part, i) => 
                    part.match(/https?:\/\//) ? (
                      <a key={i} href={part} target="_blank" rel="noopener noreferrer" className="underline font-bold text-white hover:text-primary-light break-all">
                        {part}
                      </a>
                    ) : (
                      <span key={i}>{part}</span>
                    )
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-surface-highlight border border-border p-3 rounded-lg flex gap-1">
                  <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce"></span>
                  <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce delay-100"></span>
                  <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce delay-200"></span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 bg-surface border-t border-border">
            <div className="relative flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Pregunta sobre iPhone, envíos..."
                className="flex-1 bg-background border border-border text-white text-xs p-3 focus:border-primary focus:ring-0 outline-none rounded-sm placeholder-gray-600"
              />
              <button 
                onClick={handleSend}
                disabled={isLoading || !input.trim()}
                className="p-3 bg-white text-black hover:bg-primary hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <span className="material-symbols-outlined text-sm font-bold">send</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-primary hover:bg-white text-white hover:text-black transition-all duration-300 rounded-full shadow-[0_0_30px_rgba(255,0,0,0.4)] flex items-center justify-center group relative"
      >
        {isOpen ? (
            <span className="material-symbols-outlined text-2xl font-bold">expand_more</span>
        ) : (
            <span className="material-symbols-outlined text-2xl font-bold group-hover:scale-110 transition-transform">smart_toy</span>
        )}
        
        {!isOpen && (
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 border-2 border-background rounded-full"></span>
        )}
      </button>
    </div>
  );
};

export default ChatAssistant;
