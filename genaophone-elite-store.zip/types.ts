export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  badge?: 'Nuevo' | 'Oferta' | 'Exclusivo' | 'Hot';
  specs?: {
    screen?: string;
    camera?: string;
    battery?: string;
  };
}

export interface CartItem extends Product {
  quantity: number;
}
