import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-background pt-24 pb-12 border-t border-border px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-24">
        <div>
          <a href="#" className="flex items-center gap-3 mb-10 group">
            <div className="w-8 h-8 bg-primary flex items-center justify-center transition-colors group-hover:bg-white">
              <span className="material-symbols-outlined text-black text-lg font-bold">devices</span>
            </div>
            <span className="text-xl font-black tracking-tighter uppercase italic font-display">Genao<span className="text-primary not-italic">Phone</span></span>
          </a>
          <p className="text-gray-600 text-[11px] leading-relaxed mb-10 uppercase tracking-[0.15em] font-medium max-w-[240px]">
            Curadores de la tecnología más avanzada del planeta. Rendimiento sin concesiones para el usuario exigente.
          </p>
        </div>

        <div>
          <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-white mb-10 border-l-2 border-primary pl-5">Navegación</h4>
          <ul className="space-y-5 text-[10px] font-bold uppercase tracking-[0.2em] text-gray-600">
            <li><a href="#" className="hover:text-primary transition-colors">Colección Móvil</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Gaming Rig</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Cine en Casa</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Wearables</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-white mb-10 border-l-2 border-primary pl-5">Excelencia</h4>
          <ul className="space-y-5 text-[10px] font-bold uppercase tracking-[0.2em] text-gray-600">
            <li><a href="#" className="hover:text-primary transition-colors">Servicio Técnico</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Logística Global</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Garantía Directa</a></li>
            <li><a href="#" className="hover:text-primary transition-colors">Consultoría</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-white mb-10 border-l-2 border-primary pl-5">Newsletter</h4>
          <p className="text-gray-600 text-[10px] mb-6 font-medium">SUSCRÍBETE PARA RECIBIR ACTUALIZACIONES EXCLUSIVAS.</p>
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 border border-border flex items-center justify-center hover:border-primary text-gray-600 hover:text-primary transition-all">
              <span className="material-symbols-outlined text-lg">share</span>
            </a>
            <a href="#" className="w-10 h-10 border border-border flex items-center justify-center hover:border-primary text-gray-600 hover:text-primary transition-all">
              <span className="material-symbols-outlined text-lg">public</span>
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-10 border-t border-border flex flex-col md:flex-row justify-between items-center gap-8">
        <p className="text-[9px] text-gray-700 font-bold uppercase tracking-[0.4em]">© 2024 GENAOPHONE BLACK LABEL. ALL RIGHTS RESERVED.</p>
        <div className="flex items-center gap-8 opacity-30 grayscale hover:opacity-100 transition-all duration-700">
           <span className="text-xs font-bold">VISA</span>
           <span className="text-xs font-bold">MASTERCARD</span>
           <span className="text-xs font-bold">PAYPAL</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
