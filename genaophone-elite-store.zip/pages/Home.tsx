import React from 'react';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { FEATURED_PRODUCTS, CATEGORIES } from '../constants';

const Home: React.FC = () => {
  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[85vh] flex items-center overflow-hidden bg-background border-b border-border">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,0,0,0.08),rgba(0,0,0,1)_80%)]"></div>
        
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 items-center gap-16 relative z-10 py-20">
          <div className="space-y-10 order-2 md:order-1">
            <div className="flex items-center gap-4 animate-fade-in-up">
              <span className="h-[1px] w-12 bg-primary"></span>
              <span className="text-primary font-black text-xs uppercase tracking-[0.4em]">Limited Series 2024</span>
            </div>
            
            <h1 className="text-6xl lg:text-8xl font-black leading-none tracking-tighter uppercase italic font-display">
              Pure <br/> <span className="text-primary not-italic">Performance.</span>
            </h1>
            
            <p className="text-lg text-gray-500 max-w-md font-light leading-relaxed">
              Elevando el estándar de la tecnología móvil. Diseño minimalista, potencia sin precedentes. Solo en GenaoPhone.
            </p>
            
            <div className="flex flex-wrap gap-6 pt-4">
              <Link to="/category" className="bg-primary text-white px-12 py-5 rounded-sm font-black uppercase tracking-[0.2em] text-xs hover:scale-105 transition-transform shadow-[0_0_30px_rgba(255,0,0,0.3)]">
                Adquirir Ahora
              </Link>
              <Link to="/category" className="border border-white/10 px-12 py-5 rounded-sm font-black uppercase tracking-[0.2em] text-xs hover:bg-white hover:text-black transition-all">
                Explorar
              </Link>
            </div>
          </div>
          
          <div className="relative group order-1 md:order-2 flex justify-center">
            <div className="absolute inset-0 bg-primary/20 blur-[120px] rounded-full opacity-40 group-hover:opacity-60 transition-opacity duration-1000"></div>
            <img 
              alt="Flagship Device" 
              className="relative w-[80%] md:w-full h-auto object-contain z-10 animate-float mix-blend-screen" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuC29vucHeImqNCnxvLkjSuiqoTeAvFs7pbX7r3gGq8MOJUmYto807n1bnbFGWx2sgmZbzCa1c0P04YPyFkmkQyO6b_a19-crNuQKrphxpwrq10brJEFdW3airmcA4BDLM2k9xmWRX5J48ZK3t3NnGwbrCPlNnbdFZq4sHZkkRYtHLPYWR2Y1VqVze1ONfEL0siz8Avsy_NgGdujUTUasjOmvlSpKgWCAOjtiK0vhWnjQBQ6KYHS0xzdO3Ax3HT_C5TWaRtOkvuD-So"
            />
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="bg-background py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {CATEGORIES.map((cat, idx) => (
              <Link to="/category" key={idx} className="group relative overflow-hidden h-[450px] border border-border bg-surface block rounded-sm">
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors z-10"></div>
                
                {/* Image adjusted to cover the full card area */}
                <img 
                  alt={cat.title} 
                  className="w-full h-full object-cover opacity-80 group-hover:scale-110 group-hover:opacity-100 transition-all duration-700 ease-out" 
                  src={cat.image}
                />
                
                <div className="absolute inset-0 p-8 flex flex-col justify-end bg-gradient-to-t from-black via-black/40 to-transparent z-20">
                  <span className="text-xs font-black text-primary uppercase tracking-[0.3em] mb-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-500 delay-75">{cat.subtitle}</span>
                  <h3 className="text-3xl font-black uppercase italic font-display translate-y-4 group-hover:translate-y-0 transition-transform duration-500 text-white leading-none">{cat.title}</h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Premium Selection */}
      <section className="bg-background py-24 px-6 border-t border-border">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-baseline mb-16 gap-4">
            <div>
              <h2 className="text-4xl lg:text-5xl font-black uppercase italic tracking-tighter font-display">Selección <span className="text-primary not-italic">Premium</span></h2>
              <p className="text-gray-600 text-xs uppercase tracking-widest mt-3 font-bold">Curaduría de dispositivos de alto rendimiento</p>
            </div>
            <Link to="/category" className="text-xs font-black uppercase tracking-[0.2em] border-b border-primary text-primary pb-1 hover:text-white hover:border-white transition-colors">
              Ver Todo el Arsenal
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURED_PRODUCTS.slice(2, 6).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-surface border-y border-border py-20 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
          {[
            { icon: 'local_shipping', title: 'Logística Global', text: 'Envíos asegurados con seguimiento en tiempo real 24/7.' },
            { icon: 'security', title: 'Cifrado Militar', text: 'Tus transacciones están protegidas bajo estándares de alta seguridad.' },
            { icon: 'support', title: 'Soporte Concierge', text: 'Atención personalizada para clientes de nuestra red exclusiva.' }
          ].map((feature, idx) => (
            <div key={idx} className={`flex flex-col items-center text-center space-y-6 ${idx === 1 ? 'md:border-x border-border/50 md:px-12' : ''}`}>
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-2">
                <span className="material-symbols-outlined text-3xl">{feature.icon}</span>
              </div>
              <div>
                 <h4 className="font-black uppercase text-xs tracking-[0.3em] mb-3 text-white">{feature.title}</h4>
                 <p className="text-gray-500 text-[11px] leading-relaxed max-w-[220px] mx-auto uppercase tracking-wide">{feature.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Newsletter */}
      <section className="bg-background py-32 px-6 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-primary/10 blur-[150px] rounded-full pointer-events-none"></div>
        <div className="max-w-xl mx-auto text-center relative z-10 space-y-10">
          <div className="space-y-4">
            <h2 className="text-5xl lg:text-7xl font-black italic tracking-tighter uppercase font-display">Inner <span className="text-primary not-italic">Circle</span></h2>
            <p className="text-gray-500 text-sm tracking-widest font-bold uppercase">ACCESO ANTICIPADO A LANZAMIENTOS Y EVENTOS</p>
          </div>
          <form className="flex flex-col gap-6" onSubmit={(e) => e.preventDefault()}>
            <input 
              type="email" 
              placeholder="TU@EMAIL.COM" 
              className="w-full px-0 py-4 bg-transparent border-b-2 border-border focus:border-primary outline-none text-white text-center text-xl placeholder-white/20 font-bold uppercase tracking-wider"
            />
            <button className="bg-primary text-white py-5 font-black uppercase tracking-[0.4em] text-xs hover:bg-white hover:text-black transition-all shadow-lg shadow-primary/25">
              Registrarme
            </button>
          </form>
        </div>
      </section>
    </>
  );
};

export default Home;