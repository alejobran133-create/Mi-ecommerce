import { Product } from './types';

export const FEATURED_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'iPhone 15 Pro Max',
    brand: 'Apple',
    price: 1199,
    originalPrice: 1299,
    category: 'Smartphones',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC29vucHeImqNCnxvLkjSuiqoTeAvFs7pbX7r3gGq8MOJUmYto807n1bnbFGWx2sgmZbzCa1c0P04YPyFkmkQyO6b_a19-crNuQKrphxpwrq10brJEFdW3airmcA4BDLM2k9xmWRX5J48ZK3t3NnGwbrCPlNnbdFZq4sHZkkRYtHLPYWR2Y1VqVze1ONfEL0siz8Avsy_NgGdujUTUasjOmvlSpKgWCAOjtiK0vhWnjQBQ6KYHS0xzdO3Ax3HT_C5TWaRtOkvuD-So',
    badge: 'Exclusivo',
    specs: { screen: '6.7" OLED', camera: '48MP Pro', battery: '4,422 mAh' }
  },
  {
    id: '2',
    name: 'Galaxy S24 Ultra 512GB',
    brand: 'Samsung',
    price: 1049,
    originalPrice: 1300,
    category: 'Smartphones',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBX076iult1es3mbQQjPfbYV0oYhub74uh7zhcgn1wUXwQ1fUXwS9P_ukOE11qIborwAPf1CVZS4TUboM_8JAg9xJq94GLIs9cZ_lazCMEUkgHl2fPA2ihsfNgI4g174QEM0c6I3TXwoUojXPqkIvIqLUeek5EtDbIAPnupZ9CHNo9Y6lMhGv-iJw8lu5l7AER9uI22HZE5oTYLG2bnvq_uybCeSHj7mWMlXN-n5MlF_kKuAi0stbu_C1J_Pox6Abb7Ybiph8ldjoM',
    badge: 'Oferta'
  },
  {
    id: '3',
    name: 'Control Inalámbrico Pro',
    brand: 'Consolas',
    price: 59.90,
    originalPrice: 74.90,
    category: 'Gaming',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCBzXT4PU2gxgyvwRKFzmY0uxhsXlWAaOxfL1-Q6tCl2nY-xYxQ8zcmqEOzIQBkK-bRq9VBCtkXtiJcDAEOaBWrNR2M65FWpQxX8yYElUl-awuauJvANeZxkDcA_DxoBCFHA3AasaNHes7YUytKxUxoWG97GtscOSFKE5zzkSYjvdEbGYZ5HWmcPeEgDT_pt9x4ZWabDoUStiaj6PGK5Pvvg9gw7JM8upGr4ryVpEBn8JaaeXM4mD_Dmb7K43UBxbyuvoBv-LLt6_A',
    badge: 'Oferta'
  },
  {
    id: '4',
    name: 'Headset Pro Wireless',
    brand: 'Audio',
    price: 129.90,
    category: 'Audio',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD8Ygn7lfinCZPgStydLQEkYyxfChtjDdSXvuztMAmfr5J_BKA4usXy-6UHueFKuvEUQzJsK8RFa3bjcdRoStMSVsWJeiCsBNT_Ms7rSwPDgv1F0_CqXpv0Q4O-QTx27CO0IJRsCJ1ii_rxY2FHhWX-Y3SOwm2kYx1XQXvJvEE4BsmBOavnsEOEU44DUSu-WKA87ABGErj9ZvxXjbpYRlg3CV__4pWBNNYTgupfrQv-NasCz0m57j1u5UrQbyFqcTiN-lyBMJNlvAc',
    badge: 'Nuevo'
  },
  {
    id: '5',
    name: 'Elite Pro 256GB Shadow',
    brand: 'Celulares',
    price: 749.90,
    originalPrice: 879.90,
    category: 'Smartphones',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA8L9F6i7fqsmfr73OJYRp4J6nqSqCZXsu1QvHjzjctHEjG5UZKSKB_bhlWX5-697qKX7CmnCXOGEOgjAqZJIM80_yYR3RB0s5oguPVEXUHs6gsopu_Ba7SDmS5OXiJwHs0FJDW_xLbRTSTzwexOEXnLppYNxnm5Vph1WzZMCbL48UJynn8OF2fuKvE8kaf6S4amXbhb8MkonkQv6yyVJDzXFVsv0ZgDJBJ9tfmDnL-96-_Ic2K0VC3cy6ljAuJc2_B7JyfQn4FQwE',
    badge: 'Hot'
  },
  {
    id: '6',
    name: 'Pixel 8 Pro Bay Blue',
    brand: 'Google',
    price: 899,
    category: 'Smartphones',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCoH5Nnf9zyGS_AFheD27ciy2QvZFdSNGFEy36RqUfTGQY4bydIpIwCDL_k5CRlP23wLFJ3JkbtTjrSM6FAujuP2aZkpRFojkAGiWWb1_1nIcKxp-_ce1u9Yx8bhEWo3cb3WjZ-cG66Z9A3vc5D_YL0YT29V_Z1DcG8w0H1UEnJS531f1Z55yJXILA_Gd-i6l-LJ5pkvlMKudIeBSnmJV6B4XTPoESrJZ0lGQ3AWNKfkpB5yMfSc_YjHkszkSCQp858JBHlLuxh5I4'
  }
];

export const CATEGORIES = [
  {
    title: 'Smartphones',
    subtitle: 'Mobile',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC29vucHeImqNCnxvLkjSuiqoTeAvFs7pbX7r3gGq8MOJUmYto807n1bnbFGWx2sgmZbzCa1c0P04YPyFkmkQyO6b_a19-crNuQKrphxpwrq10brJEFdW3airmcA4BDLM2k9xmWRX5J48ZK3t3NnGwbrCPlNnbdFZq4sHZkkRYtHLPYWR2Y1VqVze1ONfEL0siz8Avsy_NgGdujUTUasjOmvlSpKgWCAOjtiK0vhWnjQBQ6KYHS0xzdO3Ax3HT_C5TWaRtOkvuD-So'
  },
  {
    title: 'Ultra HD TV',
    subtitle: 'Visual',
    image: 'https://images.unsplash.com/photo-1601944177325-f8867652837f?q=80&w=2077&auto=format&fit=crop'
  },
  {
    title: 'Premium Sound',
    subtitle: 'Audio',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD8Ygn7lfinCZPgStydLQEkYyxfChtjDdSXvuztMAmfr5J_BKA4usXy-6UHueFKuvEUQzJsK8RFa3bjcdRoStMSVsWJeiCsBNT_Ms7rSwPDgv1F0_CqXpv0Q4O-QTx27CO0IJRsCJ1ii_rxY2FHhWX-Y3SOwm2kYx1XQXvJvEE4BsmBOavnsEOEU44DUSu-WKA87ABGErj9ZvxXjbpYRlg3CV__4pWBNNYTgupfrQv-NasCz0m57j1u5UrQbyFqcTiN-lyBMJNlvAc'
  },
  {
    title: 'Ecosystem',
    subtitle: 'Gaming',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCBzXT4PU2gxgyvwRKFzmY0uxhsXlWAaOxfL1-Q6tCl2nY-xYxQ8zcmqEOzIQBkK-bRq9VBCtkXtiJcDAEOaBWrNR2M65FWpQxX8yYElUl-awuauJvANeZxkDcA_DxoBCFHA3AasaNHes7YUytKxUxoWG97GtscOSFKE5zzkSYjvdEbGYZ5HWmcPeEgDT_pt9x4ZWabDoUStiaj6PGK5Pvvg9gw7JM8upGr4ryVpEBn8JaaeXM4mD_Dmb7K43UBxbyuvoBv-LLt6_A'
  }
];
