import React, { useState } from 'react';
import ProductCard from '../components/ProductCard';
import { FEATURED_PRODUCTS } from '../constants';

const Catalog: React.FC = () => {
  const [priceRange, setPriceRange] = useState([100, 2000]);

  return (
    <main className="max-w-7xl mx-auto px-6 py-12">
      {/* Header */}
      <div className="mb-14">
        <nav className="text-[10px] text-gray-600 uppercase tracking-[0.3em] mb-6 flex items-center gap-2">
          <a href="/" className="hover:text-primary transition-colors">Inicio</a>
          <span className="text-border">/</span>
          <span className="text-white">Celulares</span>
        </nav>
        <h1 className="text-5xl lg:text-7xl font-black uppercase tracking-tighter leading-[0.9] font-display">
          <span className="text-primary block mb-2">High-End</span> Celulares
        </h1>
      </div>

      <div className="flex flex-col lg:flex-row gap-16">
        {/* Sidebar */}
        <aside className="w-full lg:w-64 flex-shrink-0 space-y-16">
          
          {/* Brands Filter */}
          <div>
            <h3 className="text-[11px] font-black uppercase tracking-[0.25em] mb-8 text-white flex items-center justify-between group cursor-pointer">
              Marcas
              <span className="w-8 h-[1px] bg-primary group-hover:w-12 transition-all"></span>
            </h3>
            <div className="space-y-5">
              {['Apple', 'Samsung', 'Google', 'Xiaomi', 'Sony'].map((brand, i) => (
                <label key={brand} className="flex items-center gap-4 cursor-pointer group/item">
                  <div className="relative flex items-center">
                    <input 
                      type="checkbox" 
                      defaultChecked={i === 0}
                      className="peer w-4 h-4 border-2 border-border bg-black checked:bg-primary checked:border-primary focus:ring-0 focus:ring-offset-0 transition-all rounded-none appearance-none" 
                    />
                    <span className="material-symbols-outlined text-[10px] text-black absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 peer-checked:opacity-100 pointer-events-none">check</span>
                  </div>
                  <span className="text-xs font-bold uppercase tracking-widest text-gray-500 group-hover/item:text-white transition-colors">{brand}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Price Filter */}
          <div>
            <h3 className="text-[11px] font-black uppercase tracking-[0.25em] mb-8 text-white flex items-center justify-between">
              Presupuesto
              <span className="w-8 h-[1px] bg-primary"></span>
            </h3>
            <div className="space-y-8">
              <input 
                type="range" 
                min="100" 
                max="2000" 
                value={priceRange[1]}
                onChange={(e) => setPriceRange([100, parseInt(e.target.value)])}
                className="w-full h-[2px] bg-border appearance-none cursor-pointer accent-primary rounded-none"
              />
              <div className="flex items-center justify-between gap-4">
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] text-gray-600 font-black">USD</span>
                  <input type="number" value={priceRange[0]} readOnly className="w-full pl-10 pr-2 py-3 text-[10px] bg-surface-highlight border border-border text-white focus:border-primary focus:ring-0 uppercase font-bold text-center" />
                </div>
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] text-gray-600 font-black">USD</span>
                  <input type="number" value={priceRange[1]} readOnly className="w-full pl-10 pr-2 py-3 text-[10px] bg-surface-highlight border border-border text-white focus:border-primary focus:ring-0 uppercase font-bold text-center" />
                </div>
              </div>
            </div>
          </div>

          {/* Color Filter */}
          <div>
            <h3 className="text-[11px] font-black uppercase tracking-[0.25em] mb-8 text-white flex items-center justify-between">
              Acabado
              <span className="w-8 h-[1px] bg-primary"></span>
            </h3>
            <div className="flex flex-wrap gap-3">
              {['#1A1A1A', '#FFFFFF', '#1E3A8A', '#374151', '#EF4444'].map((color, i) => (
                <button key={i} className="w-10 h-10 rounded-none bg-surface border border-border hover:border-primary transition-all p-1.5 group">
                  <div className="w-full h-full" style={{ backgroundColor: color }}></div>
                </button>
              ))}
            </div>
          </div>

          <button className="w-full py-5 border border-border text-gray-500 text-[10px] font-black uppercase tracking-[0.3em] hover:bg-white hover:text-black hover:border-white transition-all duration-300">
            Limpiar Filtros
          </button>
        </aside>

        {/* Product Grid */}
        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-10 pb-6 border-b border-border gap-4">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">
              <span className="text-white">12</span> Resultados encontrados
            </p>
            <div className="flex items-center gap-4">
              <span className="text-[10px] font-black text-gray-600 uppercase tracking-widest">Ordenar:</span>
              <div className="relative group">
                <select className="appearance-none bg-black border border-border text-white text-[10px] font-bold uppercase tracking-widest py-3 pl-4 pr-10 focus:ring-0 focus:border-primary cursor-pointer hover:border-gray-500 transition-colors w-48">
                  <option>Exclusividad</option>
                  <option>Precio: Menor a Mayor</option>
                  <option>Precio: Mayor a Menor</option>
                  <option>Nuevos Lanzamientos</option>
                </select>
                <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm pointer-events-none group-hover:text-white transition-colors">expand_more</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURED_PRODUCTS.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
            {/* Duplicate for demo */}
            {FEATURED_PRODUCTS.slice(0,3).map((product, i) => (
               <ProductCard key={`${product.id}-dup-${i}`} product={{...product, id: `${product.id}-dup`}} />
            ))}
          </div>

          <div className="mt-20 flex justify-center">
            <button className="px-16 py-6 border border-border text-white text-[10px] font-black uppercase tracking-[0.4em] hover:bg-primary hover:border-primary hover:scale-105 transition-all duration-500 shadow-lg shadow-black">
              Cargar Más
            </button>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Catalog;
