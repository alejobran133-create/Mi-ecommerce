import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  variant?: 'grid' | 'featured';
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <Link to={`/product/${product.id}`} className="group relative bg-surface border border-border overflow-hidden transition-all duration-500 hover:border-primary/40 block h-full flex flex-col">
      {product.badge && (
        <div className="absolute top-0 left-0 z-10">
          <span className="bg-primary text-white text-[9px] font-black px-4 py-2 uppercase tracking-[0.2em]">
            {product.badge}
          </span>
        </div>
      )}
      
      <div className="relative aspect-[4/5] overflow-hidden bg-background flex items-center justify-center p-8 lg:p-12 flex-1">
        <div className="absolute inset-0 bg-radial-gradient from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-contain transition-transform duration-700 ease-out group-hover:scale-110 mix-blend-screen" 
        />
        
        <div className="absolute bottom-6 inset-x-6 opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500">
          <button className="w-full bg-primary text-white py-3 font-black uppercase tracking-[0.2em] flex items-center justify-center gap-2 text-[10px] hover:bg-white hover:text-black transition-colors shadow-lg shadow-primary/20">
            <span className="material-symbols-outlined text-sm font-light">shopping_bag</span> Comprar
          </button>
        </div>
      </div>

      <div className="p-6 border-t border-border bg-surface relative z-20">
        <p className="text-[9px] font-black text-gray-500 uppercase tracking-[0.3em] mb-2 group-hover:text-primary transition-colors">{product.brand}</p>
        <h3 className="font-bold text-white mb-4 text-sm uppercase tracking-wider h-10 line-clamp-2">{product.name}</h3>
        <div className="flex items-baseline justify-between">
          <div className="flex flex-col">
            <span className="text-lg font-black text-primary tracking-tighter">US$ {product.price.toLocaleString()}</span>
            {product.originalPrice && (
              <span className="text-[10px] text-gray-700 line-through font-bold">US$ {product.originalPrice.toLocaleString()}</span>
            )}
          </div>
          <button className="w-8 h-8 border border-border flex items-center justify-center hover:bg-white hover:text-black hover:border-white transition-all rounded-sm text-gray-500">
            <span className="material-symbols-outlined text-sm">add_shopping_cart</span>
          </button>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;