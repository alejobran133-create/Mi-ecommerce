import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { FEATURED_PRODUCTS } from '../constants';
import ProductCard from '../components/ProductCard';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  // Fallback to first product if not found or id is missing
  const product = FEATURED_PRODUCTS.find(p => p.id === id) || FEATURED_PRODUCTS[0];
  const [selectedColor, setSelectedColor] = useState(0);
  const [selectedStorage, setSelectedStorage] = useState('256GB');

  const galleryImages = [
    product.image,
    'https://lh3.googleusercontent.com/aida-public/AB6AXuDZ3usG8VDM05Mt_oIdMP1vgxA48H1DYx41CXX6PrQwdsubbmAgLUCqJmmVWWwHY9It4dkzZW2hy8hHPDFPuFzthCq8BZFwte8dbHWREhRmXQNVNTPKEROf6eefzBppExzezjkL9ty7zG5C4CflCSdXK8kfGVb-Wo9OmehcVLC83u9N1_uwqEO75P-4M36ru6TQO8RCAo4G0D2IYx8uXW_0hMzT_HH1zu1cnJFB7WoUPx7rUJknIp81qyW-jgjvowYQ67g9TKmbzOI',
    'https://lh3.googleusercontent.com/aida-public/AB6AXuAF7h5mFv2EQCffUC1BqouirJG9cfJRn8sv9L5PAxP2fgO5IOKz8S9NzCqY_rxLJ-7mZf5UgAe5OKGKP8QM7e8xdrEtEiQd6iZg__wfM8PpcOCJ-v7xGVqcWOxqaeu4q62OCZ9Gt75Bpb27eMVASaIpcQoMr07oQWvYzcthWTDME6jYzTY8CbMYT4i-EJCA6ma5JmhoewH_rOwDCgJC0PwVCVwJfGiTLFaePlOP0Ww-6PVqJiNowI1Q-bMbguKtCzPajn6vXxQuvJk',
    'https://lh3.googleusercontent.com/aida-public/AB6AXuAAUI67bBjhGigRdShsH5FTZ7nTivEba0tUVRDiwg8MtjAKthmvG6sNA7RoPkXGC2C18f_9c9aCIuWREr5FTDEcfwE6V6IinssC-GFv96pvRZixVD1BTNgFSlgZ52CNotNFN4oveFIL1rlTQSAD2-qal5Gla_FM6LSAXhU6GMgaPb0M6cF_BSV34VR4tKBZj7eSHkBgDHaoquU2WzcRr4-Z3Y6og4ovqOi4sMyI30_-2zm63wDYifYaKkA5TbALUDnUGfM_06GYNNY'
  ];
  const [activeImage, setActiveImage] = useState(galleryImages[0]);

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-3 mb-12 text-[10px] uppercase tracking-[0.2em] font-bold">
        <Link to="/" className="text-gray-600 hover:text-white transition-colors">Inicio</Link>
        <span className="text-border">/</span>
        <Link to="/category" className="text-gray-600 hover:text-white transition-colors">{product.category}</Link>
        <span className="text-border">/</span>
        <span className="text-primary">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
        {/* Left: Gallery */}
        <div className="lg:col-span-7">
          <div className="grid grid-cols-4 gap-4">
            <div className="col-span-4 aspect-square bg-surface border border-border p-8 flex items-center justify-center relative group overflow-hidden">
               <div className="absolute top-0 right-0 p-6 z-20">
                  <button className="w-10 h-10 rounded-full bg-black/50 backdrop-blur border border-white/10 flex items-center justify-center hover:bg-primary hover:border-primary transition-all text-white">
                    <span className="material-symbols-outlined text-lg">favorite</span>
                  </button>
               </div>
               <img 
                src={activeImage} 
                alt="Main View" 
                className="w-full h-full object-contain mix-blend-screen transition-transform duration-500 group-hover:scale-105" 
               />
            </div>
            {galleryImages.map((img, i) => (
              <div 
                key={i} 
                className={`aspect-square bg-surface border cursor-pointer p-2 flex items-center justify-center transition-all ${activeImage === img ? 'border-primary' : 'border-border hover:border-white/50'}`}
                onClick={() => setActiveImage(img)}
              >
                <img src={img} className="w-full h-full object-contain mix-blend-screen" alt="Thumbnail" />
              </div>
            ))}
          </div>
        </div>

        {/* Right: Product Info */}
        <div className="lg:col-span-5 flex flex-col gap-8">
          <div>
            <div className="flex items-center gap-3 mb-6">
                <span className="inline-block px-3 py-1 bg-primary/10 text-primary text-[10px] font-black uppercase tracking-[0.2em]">Novedad</span>
                <span className="flex items-center gap-1 text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                    <span className="material-symbols-outlined text-sm text-yellow-500">star</span> 4.9 (120 Reviews)
                </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-black leading-tight mb-4 font-display uppercase tracking-tight">{product.name}</h1>
            <p className="text-gray-500 text-sm leading-relaxed max-w-md">Forjado en titanio. Chip A17 Pro. La cámara más potente de un iPhone. Experimenta el futuro hoy.</p>
          </div>

          <div className="flex items-baseline gap-4 py-6 border-y border-border">
            <h2 className="text-4xl font-black text-primary tracking-tighter">US$ {product.price.toLocaleString()}</h2>
            {product.originalPrice && (
                <span className="text-gray-600 line-through text-lg font-bold">US$ {product.originalPrice.toLocaleString()}</span>
            )}
          </div>

          {/* Specs */}
          <div className="grid grid-cols-3 gap-3">
            {[
                { icon: 'screenshot', label: 'Pantalla', val: product.specs?.screen || '6.7" OLED' },
                { icon: 'camera', label: 'Cámara', val: product.specs?.camera || '48MP Pro' },
                { icon: 'battery_charging_full', label: 'Batería', val: product.specs?.battery || '4422 mAh' }
            ].map((spec, i) => (
                <div key={i} className="bg-surface border border-border p-4 flex flex-col items-center text-center gap-2 group hover:border-primary/50 transition-colors">
                    <span className="material-symbols-outlined text-primary group-hover:scale-110 transition-transform">{spec.icon}</span>
                    <p className="text-[9px] text-gray-500 uppercase tracking-widest font-bold">{spec.label}</p>
                    <p className="text-xs font-bold text-white">{spec.val}</p>
                </div>
            ))}
          </div>

          {/* Selection: Color */}
          <div className="space-y-4">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500">Color: <span className="text-white">Titanio Natural</span></p>
            <div className="flex gap-4">
              {['#bebaad', '#464647', '#242526', '#f2f1ed'].map((c, i) => (
                <button 
                    key={i} 
                    className={`w-12 h-12 rounded-full border-2 transition-all ${selectedColor === i ? 'border-primary ring-2 ring-primary/20 scale-110' : 'border-transparent hover:border-gray-500'}`}
                    onClick={() => setSelectedColor(i)}
                >
                    <div className="w-full h-full rounded-full border border-black/20" style={{ backgroundColor: c }}></div>
                </button>
              ))}
            </div>
          </div>

          {/* Selection: Storage */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500">Capacidad</p>
                <a href="#" className="text-[10px] text-primary underline decoration-primary/50 hover:text-white transition-colors">Guía de almacenamiento</a>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {['256GB', '512GB', '1TB'].map((size) => (
                <button 
                    key={size}
                    onClick={() => setSelectedStorage(size)}
                    className={`py-4 px-2 border text-[11px] font-black uppercase tracking-wider transition-all ${selectedStorage === size ? 'border-primary bg-primary/10 text-white shadow-[0_0_15px_rgba(255,0,0,0.1)]' : 'border-border bg-surface text-gray-500 hover:border-gray-500 hover:text-white'}`}
                >
                    {size}
                </button>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div className="flex flex-col gap-3 mt-4">
            <button className="w-full bg-primary hover:bg-white hover:text-black text-white font-black uppercase tracking-[0.2em] py-5 text-xs flex items-center justify-center gap-3 transition-all shadow-lg shadow-primary/20 group">
              <span className="material-symbols-outlined text-lg group-hover:scale-110 transition-transform">shopping_bag</span>
              Añadir al Carrito
            </button>
            <button className="w-full border border-border bg-transparent hover:bg-surface text-white font-black uppercase tracking-[0.2em] py-5 text-xs transition-all">
               Comprar ahora
            </button>
          </div>
          
          <p className="text-center text-[10px] text-gray-500 flex items-center justify-center gap-2 uppercase tracking-wider font-bold">
             <span className="material-symbols-outlined text-sm text-primary">local_shipping</span>
             Envío gratis en 24-48h a todo el país
          </p>
        </div>
      </div>

      {/* Detailed Description */}
      <section className="mt-24 border-t border-border pt-16">
        <h3 className="text-3xl font-black uppercase italic font-display mb-12">Descripción <span className="text-primary">Detallada</span></h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <p className="text-gray-400 leading-relaxed text-sm font-light">
                El iPhone 15 Pro Max es el primer iPhone con un diseño de titanio de calidad aeroespacial, fabricado con la misma aleación que se usa en las naves espaciales enviadas a Marte. Esto lo hace increíblemente resistente y ligero.
            </p>
            <p className="text-gray-400 leading-relaxed text-sm font-light">
                El chip A17 Pro representa un cambio radical en la historia de los procesadores de Apple, ofreciendo el mejor rendimiento gráfico visto hasta ahora en un smartphone. Disfruta de juegos móviles con un nivel de detalle increíble y una velocidad asombrosa.
            </p>
            <ul className="space-y-6 pt-4">
              {[
                  "Sistema de cámaras Pro con zoom óptico de 5x.",
                  "Nuevo botón de Acción personalizable.",
                  "Conector USB-C compatible con USB 3 para transferencias veloces.",
                  "Batería para todo el día con hasta 29 horas de reproducción de video."
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-4 group">
                  <span className="material-symbols-outlined text-primary group-hover:scale-110 transition-transform">check_circle</span>
                  <span className="text-sm font-medium text-white group-hover:text-gray-300 transition-colors">{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-none overflow-hidden aspect-video bg-surface border border-border relative group">
             <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent z-10 flex items-end p-8">
                <p className="text-2xl font-black italic text-white/90 font-display">"Una bestia de titanio en tus manos"</p>
             </div>
             <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBWz3G4JgYEHQPOcMHUaz0Yo9cz65pgpsWImh0TtAXcnmkOQG6IZtE3B9vS0N3rah8UP6EI8G_cMk8tnrPfFOuNweanTEr0otOK5n0PdoGoQgxnFhPcAn0tspLYibRG4l8UUxZsi3oecmfLa4q1LmAMFUYdz9DF0cqr_aBfWPbAOiOsAIZfRq6dEt382tCPPTPNhqEvZoomcSe7m-q-L5zUyyuHa13s7XHpRN3EkNuRpu3hjchxYI1PbKFYCEoXVQ6MYKcIiBmycUc" 
                alt="Lifestyle"
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 opacity-60 group-hover:opacity-100"
             />
          </div>
        </div>
      </section>

      {/* Related Products */}
      <section className="mt-32 pb-12 border-t border-border pt-16">
        <div className="flex items-center justify-between mb-12">
            <h3 className="text-2xl font-black uppercase italic font-display">Productos <span className="text-primary">Relacionados</span></h3>
            <div className="flex gap-2">
                <button className="w-10 h-10 border border-border flex items-center justify-center hover:bg-white hover:text-black transition-all">
                    <span className="material-symbols-outlined">chevron_left</span>
                </button>
                <button className="w-10 h-10 border border-border flex items-center justify-center hover:bg-white hover:text-black transition-all">
                    <span className="material-symbols-outlined">chevron_right</span>
                </button>
            </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURED_PRODUCTS.slice(0, 4).map((product) => (
                <ProductCard key={product.id} product={product} />
            ))}
        </div>
      </section>
    </div>
  );
};

export default ProductDetail;
